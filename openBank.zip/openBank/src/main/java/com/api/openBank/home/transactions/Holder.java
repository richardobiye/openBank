package com.api.openBank.home.transactions;

/**
 * this is the account holder object
 * holds holder account name.
 */
public class Holder {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
