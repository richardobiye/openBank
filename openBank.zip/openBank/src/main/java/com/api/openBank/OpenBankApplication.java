package com.api.openBank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpenBankApplication {

	public static void main(String[] args) {
		SpringApplication.run(OpenBankApplication.class, args);
	}

}
