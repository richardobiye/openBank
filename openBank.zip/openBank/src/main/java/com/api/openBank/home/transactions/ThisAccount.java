package com.api.openBank.home.transactions;

/**
 * this is the this_account object
 */
public class ThisAccount {
    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
